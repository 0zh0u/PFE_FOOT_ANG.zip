# PFE Trem

Projet d'école d'ingénieur (ECE) de l'équipe Trem.

Application web & mobile pour un coach d'une équipe de foot : gestion de ses équipes et de ses joueurs, organisation d'événements (match / entrainements ...) et consultation de statistiques.
